#ifndef _RTOIDSTR_H_INCLUDED
#define _RTOIDSTR_H_INCLUDED

#include "asn1type.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

EXTERNRT ASN1BOOL rtStrToOid(
    const char* src,
    ASN1OBJID* tgt);

EXTERNRT ASN1BOOL rtOidToStr (
    const ASN1OBJID* src,
    char* tgt,
    size_t tgt_len);

/* Length is without trailing \0 */
EXTERNRT size_t rtOidToStrLen (const ASN1OBJID* src);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _RTOIDSTR_H_INCLUDED */
